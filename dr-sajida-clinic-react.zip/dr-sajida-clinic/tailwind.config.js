/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        bg: '#F5F7F2',
        bgAlt: '#EDF1E9',
        ink: '#152A3A',
        inkSoft: '#3E5566',
        sage: '#587A5F',
        sageDeep: '#3F5C46',
        navyDeep: '#1C3244',
        ochre: '#D98E4A',
        ochreSoft: '#F2DCC0',
        line: '#DCE3D6',
      },
      fontFamily: {
        display: ['Fraunces', 'serif'],
        body: ['"Work Sans"', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      boxShadow: {
        soft: '0 20px 50px -25px rgba(21,42,58,0.35)',
      },
      keyframes: {
        floaty: {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-10px)' },
        },
        scrollpulse: {
          '0%': { transform: 'translateX(0)' },
          '100%': { transform: 'translateX(-50%)' },
        },
      },
      animation: {
        floaty: 'floaty 5s ease-in-out infinite',
        pulse_scroll: 'scrollpulse 18s linear infinite',
      },
    },
  },
  plugins: [],
}
