import Navbar from './components/Navbar.jsx'
import Hero from './components/Hero.jsx'
import PulseStrip from './components/PulseStrip.jsx'
import Vitals from './components/Vitals.jsx'
import About from './components/About.jsx'
import Services from './components/Services.jsx'
import Approach from './components/Approach.jsx'
import Testimonials from './components/Testimonials.jsx'
import Booking from './components/Booking.jsx'
import Footer from './components/Footer.jsx'

export default function App() {
  return (
    <div className="overflow-x-hidden">
      <Navbar />
      <Hero />
      <PulseStrip />
      <Vitals />
      <About />
      <Services />
      <Approach />
      <Testimonials />
      <Booking />
      <Footer />
    </div>
  )
}
