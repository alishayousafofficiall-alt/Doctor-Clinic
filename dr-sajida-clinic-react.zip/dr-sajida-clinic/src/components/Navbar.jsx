import { useEffect, useState } from 'react'

const LINKS = [
  { href: '#about', label: 'About' },
  { href: '#services', label: 'Services' },
  { href: '#approach', label: 'Approach' },
  { href: '#testimonials', label: 'Patients' },
  { href: '#booking', label: 'Contact' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 backdrop-blur-md bg-bg/85 transition-shadow ${
        scrolled ? 'border-b border-line shadow-[0_6px_24px_-18px_rgba(21,42,58,0.4)]' : 'border-b border-transparent'
      }`}
    >
      <nav className="max-w-[1180px] mx-auto flex items-center justify-between px-6 md:px-8 py-5">
        <div className="flex items-center gap-2.5">
          <svg width="34" height="34" viewBox="0 0 34 34" fill="none">
            <circle cx="17" cy="17" r="16" stroke="#587A5F" strokeWidth="1.4" />
            <path
              d="M6 18 L12 18 L14.5 11 L18.5 25 L21 18 L28 18"
              stroke="#D98E4A"
              strokeWidth="1.8"
              fill="none"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <div className="font-display font-semibold text-[1.08rem] leading-tight">
            Dr. Sajida
            <span className="block font-mono text-[0.62rem] tracking-widest text-sage uppercase font-normal">
              Internal Medicine Clinic
            </span>
          </div>
        </div>

        <div className="hidden md:flex gap-9 text-[0.92rem] font-medium">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="relative text-inkSoft hover:text-ink transition-colors py-1 group"
            >
              {l.label}
              <span className="absolute left-0 bottom-0 w-0 h-[1.5px] bg-ochre transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </div>

        <a
          href="#booking"
          className="hidden md:inline-flex bg-navyDeep text-white px-[22px] py-[11px] rounded-full text-[0.88rem] font-semibold hover:bg-sageDeep hover:-translate-y-0.5 transition-all"
        >
          Book Appointment
        </a>

        <button
          className="md:hidden flex flex-col gap-[5px]"
          aria-label="Menu"
          onClick={() => setOpen((v) => !v)}
        >
          <span className="w-6 h-0.5 bg-ink block" />
          <span className="w-6 h-0.5 bg-ink block" />
          <span className="w-6 h-0.5 bg-ink block" />
        </button>
      </nav>

      {open && (
        <div className="md:hidden flex flex-col gap-4 px-8 pb-6 bg-bg shadow-lg">
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="text-inkSoft font-medium">
              {l.label}
            </a>
          ))}
          <a href="#booking" onClick={() => setOpen(false)} className="bg-navyDeep text-white text-center px-5 py-3 rounded-full font-semibold">
            Book Appointment
          </a>
        </div>
      )}
    </header>
  )
}
