import Reveal from './Reveal.jsx'

export default function Hero() {
  return (
    <section className="pt-[168px] pb-[100px] relative">
      <div className="max-w-[1180px] mx-auto px-6 md:px-8 grid grid-cols-1 md:grid-cols-[1.05fr_0.95fr] gap-12 md:gap-16 items-center">
        <div>
          <Reveal>
            <p className="eyebrow">Family &amp; Internal Medicine · Multan</p>
          </Reveal>
          <Reveal delay={100}>
            <h1 className="font-display font-semibold text-[2.4rem] md:text-[3.4rem] leading-[1.12] mt-4 mb-5">
              Care that starts with <em className="italic text-sageDeep">listening</em>, not a prescription pad.
            </h1>
          </Reveal>
          <Reveal delay={200}>
            <p className="text-[1.08rem] text-inkSoft max-w-[460px] mb-8">
              Twelve years of general and internal medicine practice, built around unhurried consultations,
              clear explanations, and follow-through — for the whole family, not just the illness in front of us.
            </p>
          </Reveal>
          <Reveal delay={300}>
            <div className="flex items-center gap-4 flex-wrap mb-11">
              <a
                href="#booking"
                className="inline-flex items-center gap-2.5 bg-ochre text-navyDeep px-[30px] py-[15px] rounded-full font-semibold text-[0.95rem] shadow-[0_14px_30px_-14px_rgba(217,142,74,0.65)] hover:-translate-y-0.5 hover:shadow-[0_18px_34px_-12px_rgba(217,142,74,0.75)] transition-all"
              >
                Book a Consultation
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M5 12h14M13 6l6 6-6 6" />
                </svg>
              </a>
              <a href="tel:+924710000000" className="inline-flex items-center font-semibold text-[0.95rem] border-b-[1.5px] border-ink py-[15px]">
                +92 61 000 0000
              </a>
            </div>
          </Reveal>
          <Reveal delay={400}>
            <div className="flex gap-8 flex-wrap">
              <div className="border-l-2 border-ochre pl-3.5">
                <div className="font-mono text-[1.35rem] font-medium text-navyDeep">12+</div>
                <div className="text-[0.78rem] text-inkSoft">Years in practice</div>
              </div>
              <div className="border-l-2 border-ochre pl-3.5">
                <div className="font-mono text-[1.35rem] font-medium text-navyDeep">9k+</div>
                <div className="text-[0.78rem] text-inkSoft">Patients cared for</div>
              </div>
              <div className="border-l-2 border-ochre pl-3.5">
                <div className="font-mono text-[1.35rem] font-medium text-navyDeep">4.9</div>
                <div className="text-[0.78rem] text-inkSoft">Average patient rating</div>
              </div>
            </div>
          </Reveal>
        </div>

        <Reveal delay={150} className="relative order-first md:order-last max-w-[380px] md:max-w-none mx-auto">
          <div className="relative rounded-[26px_26px_26px_6px] overflow-hidden shadow-soft aspect-[4/4.9]">
            <img
              src="https://images.unsplash.com/photo-1758691462651-611d730c5272?fm=jpg&q=80&w=1200&auto=format&fit=crop"
              alt="Dr. Sajida in her clinic"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-navyDeep/60" />
            <div className="absolute left-[22px] bottom-5 right-[22px] text-white">
              <div className="font-display font-semibold text-[1.15rem]">Dr. Sajida</div>
              <div className="font-mono text-[0.7rem] tracking-wider uppercase opacity-85 mt-0.5">
                MBBS · FCPS Internal Medicine
              </div>
            </div>
          </div>

          <div className="hidden md:flex absolute -top-[6%] -left-[13%] bg-white rounded-2xl shadow-[0_24px_40px_-20px_rgba(21,42,58,0.3)] px-[18px] py-4 items-center gap-3 animate-floaty">
            <div className="w-[38px] h-[38px] rounded-full bg-bgAlt flex items-center justify-center flex-shrink-0">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#3F5C46" strokeWidth="2">
                <path d="M12 21s-7-4.35-9.5-8.5C.9 9 2 5.5 5.5 5c2-.3 3.5.8 4.5 2.2C11 5.8 12.5 4.7 14.5 5 18 5.5 19.1 9 16.5 12.5 14 16.65 12 21 12 21z" />
              </svg>
            </div>
            <div>
              <strong className="block font-display font-semibold text-[0.92rem]">Same-day slots</strong>
              <span className="text-[0.74rem] text-inkSoft">Open Mon–Sat</span>
            </div>
          </div>

          <div
            className="hidden md:flex absolute bottom-[8%] -right-[12%] bg-white rounded-2xl shadow-[0_24px_40px_-20px_rgba(21,42,58,0.3)] px-[18px] py-4 items-center gap-3 animate-floaty"
            style={{ animationDelay: '1.4s' }}
          >
            <div className="w-[38px] h-[38px] rounded-full bg-bgAlt flex items-center justify-center flex-shrink-0">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#3F5C46" strokeWidth="2">
                <path d="M9 12l2 2 4-4M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <strong className="block font-display font-semibold text-[0.92rem]">Verified physician</strong>
              <span className="text-[0.74rem] text-inkSoft">PMDC Reg. #55127</span>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
