export default function Footer() {
  return (
    <footer className="bg-ink text-white/75 pt-[70px] pb-[30px]">
      <div className="max-w-[1180px] mx-auto px-6 md:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1fr] gap-10 mb-14">
          <div>
            <div className="font-display font-semibold text-white text-[1.08rem]">
              Dr. Sajida
              <span className="block font-mono text-[0.62rem] tracking-widest text-sage uppercase font-normal mt-1">
                Internal Medicine Clinic
              </span>
            </div>
            <p className="text-[0.88rem] mt-3.5 max-w-[280px] text-white/55">
              Independent family and internal medicine practice in Multan, focused on unhurried, continuous care.
            </p>
          </div>
          <div>
            <h4 className="text-white text-[0.82rem] uppercase tracking-wider mb-4 font-semibold">Clinic</h4>
            <a href="#about" className="block text-[0.88rem] mb-2.5 text-white/60 hover:text-white transition-colors">About the doctor</a>
            <a href="#services" className="block text-[0.88rem] mb-2.5 text-white/60 hover:text-white transition-colors">Services</a>
            <a href="#approach" className="block text-[0.88rem] mb-2.5 text-white/60 hover:text-white transition-colors">Our approach</a>
          </div>
          <div>
            <h4 className="text-white text-[0.82rem] uppercase tracking-wider mb-4 font-semibold">Visit</h4>
            <span className="block text-[0.88rem] mb-2.5 text-white/60">Cantt Medical Plaza, Multan</span>
            <span className="block text-[0.88rem] mb-2.5 text-white/60">Mon–Sat · 10AM–8PM</span>
            <a href="#booking" className="block text-[0.88rem] mb-2.5 text-white/60 hover:text-white transition-colors">Book appointment</a>
          </div>
          <div>
            <h4 className="text-white text-[0.82rem] uppercase tracking-wider mb-4 font-semibold">Contact</h4>
            <a href="tel:+924710000000" className="block text-[0.88rem] mb-2.5 text-white/60 hover:text-white transition-colors">+92 61 000 0000</a>
            <a href="mailto:clinic@drsajida.com" className="block text-[0.88rem] mb-2.5 text-white/60 hover:text-white transition-colors">clinic@drsajida.com</a>
          </div>
        </div>
        <div className="border-t border-white/10 pt-6 flex justify-between flex-wrap gap-2.5 text-[0.78rem] text-white/45">
          <span>© 2026 Dr. Sajida Clinic. All rights reserved.</span>
          <span>Design &amp; build by Alisha Yousaf</span>
        </div>
      </div>
    </footer>
  )
}
