export default function PulseStrip() {
  const line =
    '0,32 60,32 80,32 95,10 110,54 125,32 140,32 200,32 220,32 235,16 250,48 265,32 280,32 340,32 360,32 375,10 390,54 405,32 420,32 480,32 500,32 515,16 530,48 545,32 560,32 600,32'

  const Track = (
    <svg viewBox="0 0 600 64" className="h-16 w-auto flex-shrink-0">
      <polyline points={line} className="fill-none stroke-ochre stroke-2" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="600" cy="32" r="4" className="fill-ochre" />
    </svg>
  )

  return (
    <div className="bg-navyDeep overflow-hidden border-y border-white/10">
      <div className="flex items-center w-[200%] animate-pulse_scroll">
        {Track}
        {Track}
      </div>
    </div>
  )
}
