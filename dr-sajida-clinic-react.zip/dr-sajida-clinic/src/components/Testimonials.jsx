import Reveal from './Reveal.jsx'

const TESTIMONIALS = [
  {
    initial: 'S.',
    name: 'Sana R.',
    since: 'Patient since 2023',
    quote:
      'First doctor in years who actually explained my lab results instead of just handing me a prescription. I finally understood what was going on with my thyroid.',
  },
  {
    initial: 'B.',
    name: 'Bilal A.',
    since: 'Patient since 2021',
    quote:
      "My father's blood pressure has been steady for the first time in years. The follow-up calls make a real difference for an elderly patient like him.",
  },
  {
    initial: 'F.',
    name: 'Fatima N.',
    since: 'Patient since 2024',
    quote:
      'Got a same-day slot when my daughter spiked a fever on a Sunday evening. Calm, thorough, and never made us feel rushed out the door.',
  },
]

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-[110px] bg-navyDeep text-white">
      <div className="max-w-[1180px] mx-auto px-6 md:px-8">
        <Reveal>
          <p className="eyebrow [&::before]:bg-ochre text-ochreSoft">Patient notes</p>
        </Reveal>
        <Reveal delay={100}>
          <h2 className="font-display font-semibold text-white text-[1.9rem] md:text-[2.4rem] mt-3.5 mb-12 max-w-[520px]">
            What patients say after their first visit.
          </h2>
        </Reveal>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t, i) => (
            <Reveal key={t.name} delay={i * 120}>
              <div className="bg-white/5 border border-white/10 rounded-[18px] p-[30px_26px] h-full">
                <div className="font-display text-[2.4rem] text-ochre leading-none mb-1.5">&ldquo;</div>
                <p className="text-[0.95rem] text-white/80 mb-5 min-h-[96px]">{t.quote}</p>
                <div className="flex items-center gap-3">
                  <div className="w-[38px] h-[38px] rounded-full bg-sage flex items-center justify-center font-display font-semibold text-[0.85rem]">
                    {t.initial}
                  </div>
                  <div>
                    <strong className="block text-[0.9rem]">{t.name}</strong>
                    <span className="text-[0.76rem] text-white/60">{t.since}</span>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
