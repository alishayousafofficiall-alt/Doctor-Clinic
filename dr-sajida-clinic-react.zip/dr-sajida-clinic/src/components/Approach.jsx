import Reveal from './Reveal.jsx'

const POINTS = [
  'One doctor, every visit — no rotating physicians',
  'Full medical history kept and reviewed at every appointment',
  'Follow-up calls for chronic and ongoing conditions',
]

export default function Approach() {
  return (
    <section id="approach" className="py-[120px]">
      <div className="max-w-[1180px] mx-auto px-6 md:px-8 grid grid-cols-1 md:grid-cols-2 gap-14 items-center">
        <Reveal>
          <div className="rounded-[26px_6px_26px_26px] overflow-hidden shadow-soft aspect-[5/4.3]">
            <img
              src="https://images.unsplash.com/photo-1758691462878-6edc3d3da1be?fm=jpg&q=80&w=1200&auto=format&fit=crop"
              alt="Dr. Sajida consulting with a patient"
              className="w-full h-full object-cover"
            />
          </div>
        </Reveal>

        <Reveal delay={120}>
          <p className="eyebrow">The approach</p>
          <h2 className="font-display font-semibold text-[1.9rem] md:text-[2.4rem] mt-3.5 mb-5">
            Slower consultations, on purpose.
          </h2>
          <p className="text-inkSoft mb-3.5 max-w-[520px]">
            Most clinic visits are rushed because the schedule demands it. This one doesn't. Appointments are
            spaced to leave time for a full history, a real examination, and a plan explained in plain language
            — not just a prescription.
          </p>
          <ul className="flex flex-col gap-4 mt-6">
            {POINTS.map((p) => (
              <li key={p} className="flex gap-3.5 items-start">
                <div className="w-[22px] h-[22px] rounded-full bg-sage flex items-center justify-center flex-shrink-0 mt-0.5">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3">
                    <path d="M5 12l4 4 10-10" />
                  </svg>
                </div>
                <span className="text-[0.95rem] text-inkSoft">{p}</span>
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </section>
  )
}
