import { useState } from 'react'
import Reveal from './Reveal.jsx'

const INFO = [
  {
    title: 'Clinic Address',
    detail: 'Suite 4, Cantt Medical Plaza, Multan, Pakistan',
    icon: (
      <>
        <path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0118 0z" />
        <circle cx="12" cy="10" r="3" />
      </>
    ),
  },
  {
    title: 'Hours',
    detail: 'Mon–Sat, 10:00 AM – 8:00 PM',
    icon: <path d="M12 8v4l3 3M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />,
  },
  {
    title: 'Phone',
    detail: '+92 61 000 0000',
    icon: (
      <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.12.9.35 1.78.68 2.61a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.47-1.27a2 2 0 012.11-.45c.83.33 1.71.56 2.61.68A2 2 0 0122 16.92z" />
    ),
  },
]

export default function Booking() {
  const [submitted, setSubmitted] = useState(false)
  const today = new Date().toISOString().split('T')[0]

  const handleSubmit = (e) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <section id="booking" className="py-[120px]">
      <div className="max-w-[1180px] mx-auto px-6 md:px-8 grid grid-cols-1 md:grid-cols-[0.9fr_1.1fr] gap-14">
        <Reveal>
          <p className="eyebrow">Book a visit</p>
          <h2 className="font-display font-semibold text-[1.9rem] md:text-[2.4rem] mt-3.5 mb-5">Ready when you are.</h2>
          <p className="text-inkSoft mb-7 max-w-[400px]">
            Fill in a few details and the clinic will confirm your slot by phone within the same day.
          </p>
          {INFO.map((row) => (
            <div key={row.title} className="flex gap-4 items-start mb-[22px]">
              <div className="w-10 h-10 rounded-xl bg-bgAlt flex items-center justify-center flex-shrink-0">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#3F5C46" strokeWidth="2">
                  {row.icon}
                </svg>
              </div>
              <div>
                <strong className="block text-[0.95rem]">{row.title}</strong>
                <span className="text-[0.86rem] text-inkSoft">{row.detail}</span>
              </div>
            </div>
          ))}
        </Reveal>

        <Reveal delay={120}>
          <div className="bg-white border border-line rounded-[22px] p-[38px] shadow-soft">
            {!submitted ? (
              <form onSubmit={handleSubmit} className="flex flex-col gap-[18px]">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-[18px]">
                  <div className="flex flex-col gap-[7px]">
                    <label htmlFor="fname" className="text-[0.78rem] font-semibold text-inkSoft">
                      Full name
                    </label>
                    <input
                      id="fname"
                      type="text"
                      required
                      placeholder="Your name"
                      className="border border-line rounded-[10px] px-[14px] py-3 text-[0.92rem] bg-bg focus:outline-none focus:border-sage"
                    />
                  </div>
                  <div className="flex flex-col gap-[7px]">
                    <label htmlFor="fphone" className="text-[0.78rem] font-semibold text-inkSoft">
                      Phone number
                    </label>
                    <input
                      id="fphone"
                      type="tel"
                      required
                      placeholder="03xx-xxxxxxx"
                      className="border border-line rounded-[10px] px-[14px] py-3 text-[0.92rem] bg-bg focus:outline-none focus:border-sage"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-[18px]">
                  <div className="flex flex-col gap-[7px]">
                    <label htmlFor="fdate" className="text-[0.78rem] font-semibold text-inkSoft">
                      Preferred date
                    </label>
                    <input
                      id="fdate"
                      type="date"
                      required
                      min={today}
                      className="border border-line rounded-[10px] px-[14px] py-3 text-[0.92rem] bg-bg focus:outline-none focus:border-sage"
                    />
                  </div>
                  <div className="flex flex-col gap-[7px]">
                    <label htmlFor="freason" className="text-[0.78rem] font-semibold text-inkSoft">
                      Reason for visit
                    </label>
                    <select
                      id="freason"
                      className="border border-line rounded-[10px] px-[14px] py-3 text-[0.92rem] bg-bg focus:outline-none focus:border-sage"
                    >
                      <option>General consultation</option>
                      <option>Follow-up visit</option>
                      <option>Chronic condition check</option>
                      <option>Child / family care</option>
                      <option>Other</option>
                    </select>
                  </div>
                </div>
                <div className="flex flex-col gap-[7px]">
                  <label htmlFor="fnotes" className="text-[0.78rem] font-semibold text-inkSoft">
                    Anything the doctor should know beforehand?
                  </label>
                  <textarea
                    id="fnotes"
                    rows={3}
                    placeholder="Optional — symptoms, existing conditions, etc."
                    className="border border-line rounded-[10px] px-[14px] py-3 text-[0.92rem] bg-bg focus:outline-none focus:border-sage"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-navyDeep text-white py-4 rounded-full font-semibold text-[0.95rem] mt-2 hover:bg-sageDeep hover:-translate-y-0.5 transition-all"
                >
                  Request Appointment
                </button>
              </form>
            ) : (
              <div className="text-center py-[30px_10px]">
                <div className="w-[52px] h-[52px] rounded-full bg-sage flex items-center justify-center mx-auto mb-4">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M5 12l4 4 10-10" />
                  </svg>
                </div>
                <h3 className="font-display font-semibold text-[1.2rem] mb-2">Request received</h3>
                <p className="text-inkSoft text-[0.9rem]">The clinic will call to confirm your slot shortly.</p>
              </div>
            )}
          </div>
        </Reveal>
      </div>
    </section>
  )
}
