import Reveal from './Reveal.jsx'

const CREDENTIALS = [
  'MBBS — King Edward Medical University',
  'FCPS, Internal Medicine',
  'PMDC Registered',
  '12 years in practice',
]

export default function About() {
  return (
    <section id="about" className="py-[120px]">
      <div className="max-w-[1180px] mx-auto px-6 md:px-8 grid grid-cols-1 md:grid-cols-[0.85fr_1.15fr] gap-14 items-center">
        <Reveal>
          <div className="relative rounded-[6px_26px_26px_26px] overflow-hidden shadow-soft aspect-[3/3.6]">
            <img
              src="https://images.pexels.com/photos/33812025/pexels-photo-33812025.jpeg?auto=compress&cs=tinysrgb&w=1200"
              alt="Clinic reception area"
              className="w-full h-full object-cover"
            />
          </div>
        </Reveal>

        <Reveal delay={120}>
          <p className="eyebrow">About the practice</p>
          <h2 className="font-display font-semibold text-[1.9rem] md:text-[2.5rem] mt-3.5 mb-5">
            A clinic built around one physician, one relationship at a time.
          </h2>
          <p className="text-inkSoft mb-4 max-w-[560px]">
            Dr. Sajida trained in internal medicine before returning to Multan to open an independent family
            practice — one where patients see the same doctor visit after visit, and records, history, and
            context aren't lost between appointments.
          </p>
          <p className="text-inkSoft mb-4 max-w-[560px]">
            The clinic keeps daily patient numbers deliberately limited, so every consultation has room for
            questions, a full history, and a plan you actually understand before you leave the room.
          </p>
          <div className="flex flex-wrap gap-3 mt-6">
            {CREDENTIALS.map((c) => (
              <span key={c} className="font-mono text-[0.76rem] border border-line px-4 py-2 rounded-full text-inkSoft">
                {c}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  )
}
