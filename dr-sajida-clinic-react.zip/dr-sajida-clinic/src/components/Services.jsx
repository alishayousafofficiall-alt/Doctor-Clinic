import Reveal from './Reveal.jsx'

const SERVICES = [
  {
    num: '01',
    title: 'General Consultation',
    desc: 'Same-day and scheduled visits for everyday illness, symptoms, and health concerns of any kind.',
    icon: (
      <>
        <path d="M12 2a5 5 0 015 5v3a5 5 0 01-10 0V7a5 5 0 015-5z" />
        <path d="M8 14v2a4 4 0 008 0v-2M12 20v2" />
      </>
    ),
  },
  {
    num: '02',
    title: 'Chronic Disease Management',
    desc: 'Ongoing care for diabetes, hypertension, thyroid, and cardiac conditions, with ongoing follow-up.',
    icon: <path d="M22 12h-4l-3 9L9 3l-3 9H2" />,
  },
  {
    num: '03',
    title: 'Preventive Checkups',
    desc: 'Annual physicals and screening panels designed to catch problems before symptoms appear.',
    icon: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 3" />
      </>
    ),
  },
  {
    num: '04',
    title: 'Pediatric & Family Care',
    desc: 'Growth checks, vaccinations, and everyday childhood illness, alongside care for the whole household.',
    icon: (
      <>
        <path d="M4 21v-2a4 4 0 014-4h4a4 4 0 014 4v2M12 11a4 4 0 100-8 4 4 0 000 8zM20 8v6M17 11h6" />
      </>
    ),
  },
  {
    num: '05',
    title: "Women's Health",
    desc: 'Routine and reproductive health consultations in a private, unhurried setting.',
    icon: <path d="M20.8 4.6a5.5 5.5 0 00-7.8 0L12 5.6l-1-1a5.5 5.5 0 10-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 000-7.8z" />,
  },
  {
    num: '06',
    title: 'Minor Procedures & Lab',
    desc: 'In-clinic wound care, dressing, injections, and blood work with same-day results for common tests.',
    icon: (
      <>
        <rect x="3" y="4" width="18" height="16" rx="2" />
        <path d="M8 2v4M16 2v4M3 10h18" />
      </>
    ),
  },
]

export default function Services() {
  return (
    <section id="services" className="py-[100px] bg-bgAlt">
      <div className="max-w-[1180px] mx-auto px-6 md:px-8">
        <Reveal>
          <div className="flex justify-between items-end gap-10 mb-14 flex-wrap">
            <div>
              <p className="eyebrow">What we treat</p>
              <h2 className="font-display font-semibold text-[1.9rem] md:text-[2.5rem] mt-3.5 max-w-[520px]">
                Consultation to long-term care, under one roof.
              </h2>
            </div>
            <p className="text-inkSoft max-w-[340px] pb-1.5">
              Every service below starts with a full consultation — no walk-in prescriptions without an examination.
            </p>
          </div>
        </Reveal>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES.map((s, i) => (
            <Reveal key={s.num} delay={(i % 3) * 120}>
              <div className="bg-white border border-line rounded-[18px] p-8 h-full hover:-translate-y-1.5 hover:shadow-soft hover:border-transparent transition-all duration-300">
                <div className="font-mono text-[0.76rem] text-ochre">{s.num}</div>
                <svg className="w-[42px] h-[42px] my-4 stroke-sageDeep" viewBox="0 0 24 24" fill="none" strokeWidth="1.6">
                  {s.icon}
                </svg>
                <h3 className="font-display font-semibold text-[1.15rem] mb-2.5">{s.title}</h3>
                <p className="text-[0.92rem] text-inkSoft">{s.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
