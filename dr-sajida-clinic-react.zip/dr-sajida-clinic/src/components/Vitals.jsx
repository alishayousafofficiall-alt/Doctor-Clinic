import { useEffect, useRef, useState } from 'react'

const STATS = [
  { target: 9200, suffix: '+', caption: 'Patients treated to date' },
  { target: 12, suffix: 'yrs', caption: 'In independent practice' },
  { target: 18, suffix: 'min', caption: 'Average consultation time' },
  { target: 98, suffix: '%', caption: 'Patients who return or refer' },
]

function Counter({ target, suffix }) {
  const [value, setValue] = useState(0)
  const ref = useRef(null)
  const started = useRef(false)

  useEffect(() => {
    const el = ref.current
    if (!el) return
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting && !started.current) {
            started.current = true
            const step = Math.max(1, Math.round(target / 60))
            let cur = 0
            const tick = () => {
              cur += step
              if (cur >= target) {
                setValue(target)
                return
              }
              setValue(cur)
              requestAnimationFrame(tick)
            }
            tick()
          }
        })
      },
      { threshold: 0.4 },
    )
    io.observe(el)
    return () => io.disconnect()
  }, [target])

  return (
    <div ref={ref} className="font-mono text-[2.1rem] font-medium text-navyDeep flex items-baseline gap-0.5">
      {value}
      <sup className="text-[1.1rem] text-ochre">{suffix}</sup>
    </div>
  )
}

export default function Vitals() {
  return (
    <section className="py-[76px] bg-bgAlt">
      <div className="max-w-[1180px] mx-auto px-6 md:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 border border-line rounded-[20px] overflow-hidden bg-white">
          {STATS.map((s, i) => (
            <div
              key={s.caption}
              className={`p-[34px_26px] ${i !== STATS.length - 1 ? 'lg:border-r' : ''} border-b lg:border-b-0 border-line last:border-b-0`}
            >
              <Counter target={s.target} suffix={s.suffix} />
              <div className="text-[0.84rem] text-inkSoft mt-1.5">{s.caption}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
